import sys
print(sys.path)

from nest_folder.my_nest import nested_var


print(nested_var)

main_var = "main variable"